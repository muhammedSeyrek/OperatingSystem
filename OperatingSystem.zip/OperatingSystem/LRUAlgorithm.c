#include <stdio.h>
#include <stdlib.h>

static int counter = 0;
// yeni eklenecek eleman var ise islem yapma.
int exists(int elements, int *memory, int memorySize){
	for(int i = 0; i < memorySize; i++)
		if(memory[i] == elements)
			return 1;
	return 0;
}
// eger frekans'i tutan yani backtracking yaptiginda ..
// memory boyutuna ulasirsa artik sayfa degistirme yapilabilir anlami tasiyor.
int checkFreq(int *freq, int size){
	int flag = 1;
	for(int i = 0; i < size; i++)
		if(freq[i] == 0) flag = 0;
		
	if(flag) return 1;
	else return 0;
}

// frekans degerinde ilk karsilasilan bir deger alir.
// bir sonraki farkli karsilasilan degere 1 eksiltilerek bir deger atanir.
// bu sayede en kucuk elemanin index degeri minimum olarak geri dondurulur.
int minFreq(int *freq, int size){
	int min = 0;
	for(int i = 0; i < size; i++)
		if(freq[min] > freq[i])
			min = i;
	return min;
}

//memory dolduktan sonra program degistirme islemlerinin yapilacagi fonksiyon.
void fullMemory(int *array, int *memory, int memorySize, int index) {
	
	int firstProcess, freqCounter = 0, forFreq = -1;
	
	if(exists(array[index], memory, memorySize))
		return;
	
	int *freq = malloc(sizeof(memorySize) * sizeof(int));
	
	// memory'i kopyaliyoruz cunku eslestiginde forFreq degerini sirasiyla azaltarak vereccegiz.
	// bu bizim hangi programi ekleyip cikaracagimizi belirtecek.
	//memcpy(freq, memory, sizeof(memorySize) * sizeof(int));
	
	// kopyalamak yerine sifirlayip baslatabiliriz freq degiskenini.
	for(int i = 0; i < memorySize; i++) freq[i] = 0;
	
    for (int i = index - 1; i >= 0; i--) {
    	if(checkFreq(freq, memorySize)) break; //icinin dolu oldugu durum.
		for (int j = 0; j < memorySize; j++) {
	        if (array[i] == memory[j]) {
	        	// ilk bulunan degerin index'i en buyuk.
	        	// en son eklenen deger degistirilecek oge'dir.
	            freq[j] = forFreq--;
	            break;
	        }
		}	
    }
    
	// minimum'dan donen deger index'i ve programlastirilacak process.    		
    memory[minFreq(freq, memorySize)] = array[index];
    counter++;
    free(freq);
    return;
}

// anlik memory.
void listMemory(int *memory, int memorySize) {
    for (int i = 0; i < memorySize; i++) {
        printf("%d ", memory[i]);
    }
    printf("\n");
}

void main(void) {
    // process
	int array[] = {1, 2, 3, 4, 5, 3, 4, 1, 6, 7, 8, 7, 8, 9, 7, 8, 9, 5, 4, 5, 4, 2};
    int memorySize;
    char words;
    printf("Enter memory size: ");
    scanf("%d", &memorySize);

    int *memory = malloc(memorySize * sizeof(int));
    
    for (int i = 0; i < memorySize; i++) 
        memory[i] = 0;
    

    int index = 0, flag = 0;
	int indexFirst = 0;
	// tek tek process girdi edilerek calisan modulun dongusu.
    do {
        printf("Please press any button -> ");
        scanf(" %c", &words); 

		//memory'i doldugunda.
        if (flag) {
            fullMemory(array, memory, memorySize, index);
        } 
		else {
			// memory'i dolarsa.
            if(indexFirst == memorySize){
            	flag = 1;
            	fullMemory(array, memory, memorySize, index);
			}
            	
            else{
            	// memory'i dolmadiginda ve process memory'nin icinde yoksa ekleme yapsin.
            	if(!exists(array[index], memory, memorySize)){
            		memory[indexFirst++] = array[index];
            		counter++;	
				}
			}
        }
        index++;
        listMemory(memory, memorySize); //anlik memory yansitiliyor.
    } while (index < (sizeof(array) / sizeof(int)));
    //sayfa hatasi veriyor.
    printf("\n\nWrong page count: %d", counter);
    free(memory);
}

