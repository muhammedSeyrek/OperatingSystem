#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <semaphore.h>

#define MAX_PROCESSES 10
#define MESSAGE_SIZE 50

typedef struct {
    char messages[MAX_PROCESSES][MESSAGE_SIZE];
    sem_t semaphores[MAX_PROCESSES];
} SharedMemory;

SharedMemory *sharedMemory;

void MPI_Init() {
    sharedMemory = mmap(NULL, sizeof(SharedMemory), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    for (int i = 0; i < MAX_PROCESSES; i++) {
        sem_init(&sharedMemory->semaphores[i], 1, 1); // Initialize semaphores
    }
}

void MPI_Finalize() {
    munmap(sharedMemory, sizeof(SharedMemory));
}

void MPI_Send(int dest, const char *message) {
    sem_wait(&sharedMemory->semaphores[dest]);
    strcpy(sharedMemory->messages[dest], message);
    sem_post(&sharedMemory->semaphores[dest]);
}

void MPI_Recv(int source, char *message) {
    sem_wait(&sharedMemory->semaphores[source]);
    strcpy(message, sharedMemory->messages[source]);
    sem_post(&sharedMemory->semaphores[source]);
}

void process_function(int rank) {
    char message[MESSAGE_SIZE];
    if (rank % 2 == 0) { // Even rank
        if (rank + 1 < MAX_PROCESSES) {
            snprintf(message, MESSAGE_SIZE, "%d.prosesin mesaji", rank);
            MPI_Send(rank + 1, message);
            MPI_Recv(rank + 1, message);
            printf("%d numarali proses, %d numarali prosesten sunu aldi: '%s'\n", rank, rank + 1, message);
        }
    } else { // Odd rank
        if (rank - 1 >= 0) {
            MPI_Recv(rank - 1, message);
            printf("%d numarali proses, %d numarali prosesten sunu aldi: '%s'\n", rank, rank - 1, message);
            snprintf(message, MESSAGE_SIZE, "%d.prosesin mesaji", rank);
            MPI_Send(rank - 1, message);
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <number_of_processes>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    int num_processes = atoi(argv[1]);
    if (num_processes <= 0 || num_processes > MAX_PROCESSES) {
        fprintf(stderr, "Number of processes must be between 1 and %d\n", MAX_PROCESSES);
        exit(EXIT_FAILURE);
    }

    MPI_Init();

    for (int rank = 0; rank < num_processes; rank++) {
        pid_t pid = fork();
        if (pid < 0) {
            perror("Fork failed");
            exit(EXIT_FAILURE);
        } else if (pid == 0) { // Child process
            process_function(rank);
            exit(EXIT_SUCCESS);
        }
    }

    for (int i = 0; i < num_processes; i++) {
        wait(NULL); // Wait for all child processes to finish
    }

    MPI_Finalize();
    return 0;
}



























